// main_cart =document.getElementById("added")
var popchart=document.getElementById("cart")
var shirt=document.getElementById("shrit1")
shirt="AEROREADY SHIRT" 
 var EARBUBS="WIRELSS EARBUBS"
function added(){
    popchart.style.display="block"
}
var result=0;
function oneitem(){
     var list=document.createElement("div")
     list.innerHTML ="<img id='first1' src='./shirts.jpeg'  >"+shirt+"<p id='valuep'>$20</p> <button onclick='taskover(this)'>Completed</button> <button onclick='deleteItem(this)'>Delete</button>";
    console.log(list) 
    popchart.appendChild(list)
    var p1=30;
    console.log(p1)
}
function twoitem(){
    var list=document.createElement("div")
    list.innerHTML ="<img id='first1' src='./earpods.jpg'  >"+EARBUBS+"<p id='valuep'>30</p> <button onclick='taskover(this)'>Completed</button> <button onclick='deleteItem(this)'>Delete</button>";
   console.log(list) 
   popchart.appendChild(list)
   var p2=34;
   console.log(p2)
}
function threeitem(){
    var list=document.createElement("div")
    list.innerHTML ="<img id='first1' src='./hoodies.jpg'  ><h3>HOODED PARKA</h3><p id='valuep'>$20</p> <button onclick='taskover(this)'>Completed</button> <button onclick='deleteItem(this)'>Delete</button>";
   console.log(list) 
   popchart.appendChild(list)
   var p1=30;
   console.log(p1)
}
function fouritem(){
    var list=document.createElement("div")
    list.innerHTML ="<img id='first1' src='./bag.jpeg'  ><h3>BAG SCHOOL</h3><p id='valuep'>$20</p> <button onclick='taskover(this)'>Completed</button> <button onclick='deleteItem(this)'>Delete</button>";
   console.log(list) 
   popchart.appendChild(list)
   var p1=30;
   console.log(p1)
}
function fiveitem(){
    var list=document.createElement("div")
    list.innerHTML ="<img id='first1' src='./eye_glass.jpeg'><h3>eyeglass</h3><p id='valuep'>$20</p> <button onclick='taskover(this)'>Completed</button> <button onclick='deleteItem(this)'>Delete</button>";
   console.log(list) 
   popchart.appendChild(list)
   var p1=30;
   console.log(p1)
}
function buy(){
    prompt("your order placed")
       popchart.style.display="none"
}
function deleteItem(element){
    element.parentElement.remove();
    
}
// // convert this when the item add the price value need to claculate all and display in popchart
//         var popchart = document.getElementById("cart");
//         var itemList = document.getElementById("itemList");
//         var totalPriceElem = document.getElementById("totalPrice");
//         var totalPrice = 0;

//         var shirt = "AEROREADY SHIRT";
//         var earbuds = "WIRELESS EARBUDS";

//         function added() {
//             popchart.style.display = "block";
//         }

//         function updateTotalPrice(price) {
//             totalPrice += price;
//             totalPriceElem.textContent = "Total: $" + totalPrice;
//         }

//         function oneitem() {
//             addItem(shirt, 20, './shirts.jpeg');
//         }

//         function twoitem() {
//             addItem(earbuds, 30, './earpods.jpg');
//         }

//         function threeitem() {
//             addItem("HOODED PARKA", 20, './hoodies.jpg');
//         }

//         function fouritem() {
//             addItem("BAG SCHOOL", 20, './bag.jpeg');
//         }

//         function fiveitem() {
//             addItem("eyeglass", 20, './eye_glass.jpeg');
//         }

//         function addItem(name, price, imgSrc) {
//             var list = document.createElement("div");
//             list.innerHTML = `
//                 <img id='first1' src='${imgSrc}' >
//                 <h3>${name}</h3>
//                 <p id='valuep'>$${price}</p>
//                 <button onclick='taskover(this)'>Completed</button>
//                 <button onclick='deleteItem(this, ${price})'>Delete</button>
//             `;
//             itemList.appendChild(list);
//             updateTotalPrice(price);
//             popchart.style.display = "block";
//         }

//         function buy() {
//             alert("Your order is placed");
//             popchart.style.display = "none";
//             itemList.innerHTML = '';
//             totalPrice = 0;
//             totalPriceElem.textContent = "Total: $0";
//         }

//         function deleteItem(element, price) {
//             element.parentElement.remove();
//             updateTotalPrice(-price);
//         }

//         function taskover(element) {
//             element.parentElement.style.textDecoration = "line-through";
//         }
