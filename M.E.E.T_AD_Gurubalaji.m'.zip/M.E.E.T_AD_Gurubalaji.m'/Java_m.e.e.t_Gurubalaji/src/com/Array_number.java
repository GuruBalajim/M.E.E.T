package com;
import java.util.Scanner;
public class Array_number {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("enter input size ");
        int input =s.nextInt();
        System.out.println("enter the value");
        int[] arr =new int[input];
        for(int i=0;i<=input;i++) {
        	arr[i]=s.nextInt();
        }
        for(int i=0;i<=arr[i];i++) {
        System.out.println(arr[i]);}
	s.close();	
	}
}
