package com;
import java.util.Scanner;
public class sprial_xoro_ {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("enter the element size");
		int size = s.nextInt();
        char[][] arr = new char[size][size];
        int minCol = 0;
        int maxCol = size - 1;
        int minRow = 0;
        int maxRow = size - 1;
        char count = 'x';
        char innerChar = 'o';

        while (minRow <= maxRow && minCol <= maxCol) {
      
            for (int i = minCol; i <= maxCol; i++) {
                arr[minRow][i] = count;
            }
            minRow++;

            // Fill right column from top to bottom
            for (int i = minRow; i <= maxRow; i++) {
                arr[i][maxCol] = count;
            }
            maxCol--;

            // Fill bottom row from right to left
            if (minRow <= maxRow) {
                for (int i = maxCol; i >= minCol; i--) {
                    arr[maxRow][i] = count;
                }
                maxRow--;
            }

            // Fill left column from bottom to top
            if (minCol <= maxCol) {
                for (int i = maxRow; i >= minRow; i--) {
                    arr[i][minCol] = count;
                }
                minCol++;
            }
            for (int i = minRow; i <= maxRow; i++) {
                for (int j = minCol; j <= maxCol; j++) {
                    arr[i][j] = ' ';
                }
            }

            // Swap the characters for the next layer
            char temp = count;
            count = innerChar;
            innerChar = temp;
        }

        // Print the array
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
            	
                System.out.print(arr[i][j] + "\t");
            }
            System.out.println();
        }
        s.close();
    }
}

